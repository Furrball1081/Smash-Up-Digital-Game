﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class cardScript : MonoBehaviour {
	public string name;
	public int power;
	public bool action = false;
	
	// Use this for initialization
	void Start () {

	
	}
	

	// Update is called once per frame
	void Update () {
	
	}
}
